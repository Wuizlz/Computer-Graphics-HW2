/*
 * Java 3D Renderer Project. The MIT License.
 * Copyright (c) 2022-2026, rlkraft@pnw.edu
 * See LICENSE for details.
*/

/**
   Provides the renderer with an output data structure
   to hold the pixel values computed by the renderer.
*/
package renderer.framebuffer;
