/*
 * Java 3D Renderer Project. The MIT License.
 * Copyright (c) 2022-2026, rlkraft@pnw.edu
 * See LICENSE for details.
*/

/**
   Data structures for describing a 3D scene to the renderer.
*/
package renderer.scene;
