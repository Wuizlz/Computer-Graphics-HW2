/*
 * Java 3D Renderer Project. The MIT License.
 * Copyright (c) 2022-2026, rlkraft@pnw.edu
 * See LICENSE for details.
*/

/**
   Geometric primitives that describe the relationships between vertices of a model.
*/
package renderer.scene.primitives;
