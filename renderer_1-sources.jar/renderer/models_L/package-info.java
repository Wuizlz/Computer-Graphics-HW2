/*
 * Java 3D Renderer Project. The MIT License.
 * Copyright (c) 2022-2026, rlkraft@pnw.edu
 * See LICENSE for details.
*/

/**
   A library of predefined wireframe models.
*/
package renderer.models_L;
