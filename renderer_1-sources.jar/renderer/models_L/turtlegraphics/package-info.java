/*
 * Java 3D Renderer Project. The MIT License.
 * Copyright (c) 2022-2026, rlkraft@pnw.edu
 * See LICENSE for details.
*/

/**
   A library that implements Turtle Geometry with a few predefined examples of turtle graphics.
<p>
   See <a href="https://en.wikipedia.org/wiki/Turtle_graphics" target="_top">
                https://en.wikipedia.org/wiki/Turtle_graphics</a>
*/
package renderer.models_L.turtlegraphics;
