/*
 * Java 3D Renderer Project. The MIT License.
 * Copyright (c) 2022-2026, rlkraft@pnw.edu
 * See LICENSE for details.
*/

package renderer.models_L.turtlegraphics;

import renderer.scene.Model;

import java.awt.Color;

/**
   {@link Turtle} implementation of Sierpinski N-gons.
   <p>
   See <a href="https://larryriddle.agnesscott.org/ifs/pentagon/sierngon.htm" target="_top">
                https://larryriddle.agnesscott.org/ifs/pentagon/sierngon.htm</a>
   <br>
   or <a href="https://www.clear.rice.edu/comp360/lectures/fall2008/TurtleFractalsL2New.pdf#page=6" target="_top">
               https://www.clear.rice.edu/comp360/lectures/fall2008/TurtleFractalsL2New.pdf#page=6</a>
*/
public class PolygasketTurtle extends Turtle
{
   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param c      pen {@link Color} for this {@link Turtle}
      @param n      number of sides in the N-gon
      @param m      number of levels for the Polygasket
   */
   public PolygasketTurtle(final Model model, final Color c,
                           final int n, final int m)
   {
      this(model, c, n, m, 0.0, 0.0, 0.0);
   }


   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param c      pen {@link Color} for this {@link Turtle}
      @param n      number of sides in the N-gon
      @param m      number of levels for the Polygasket
      @param xPos   the intial x-coordinate for this {@link Turtle}
      @param yPos   the intial y-coordinate for this {@link Turtle}
   */
   public PolygasketTurtle(final Model model, final Color c,
                           final int n, final int m,
                           final double xPos, final double yPos)
   {
      this(model, c, n, m, xPos, yPos, 0.0);
   }


   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param c      pen {@link Color} for this {@link Turtle}
      @param n      number of sides in the N-gon
      @param m      number of levels for the Polygasket
      @param xPos   the intial x-coordinate for this {@link Turtle}
      @param yPos   the intial y-coordinate for this {@link Turtle}
      @param z      the z-plane for this {@code Turtle}
   */
   public PolygasketTurtle(final Model model, final Color c,
                           final int n, final int m,
                           final double xPos, final double yPos, final double z)
   {
      super(model, xPos, yPos, z);
      setPenColor(c);
      polygasket(n, m);
   }


   private void polygasket(final int n, final int level)
   {
      if (0 == level)
      {
         // draw a N-gon
         for (int i = 0; i < n; ++i)
         {
            forward(1);
            turn(360.0/n);
         }
      }
      else
      {
         for (int i = 0; i < n; ++i)
         {
            resize(0.5);
            polygasket(n, level - 1);
            resize(2.0);
            move(1);
            turn(360.0/n);
         }
      }
   }


   /**
      For debugging.

      @return {@link String} representation of this {@code PolygasketTurtle} object
   */
   @Override
   public String toString()
   {
      return "PolygasketTurtle:\n" + super.toString();
   }
}//PolygasketTurtle
