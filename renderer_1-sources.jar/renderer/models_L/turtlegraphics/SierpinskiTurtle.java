/*
 * Java 3D Renderer Project. The MIT License.
 * Copyright (c) 2022-2026, rlkraft@pnw.edu
 * See LICENSE for details.
*/

package renderer.models_L.turtlegraphics;

import renderer.scene.Model;

import java.awt.Color;

/**
   {@link Turtle} implementation of the Sierpinski triangle.
   <p>
   See <a href="http://en.wikipedia.org/wiki/Sierpi%C5%84ski_triangle" target="_top">
                http://en.wikipedia.org/wiki/Sierpi%C5%84ski_triangle</a>
   <br>
   or <a href="https://larryriddle.agnesscott.org/ifs/siertri/siertri.htm" target="_top">
               https://larryriddle.agnesscott.org/ifs/siertri/siertri.htm</a>
   <br>
   See <a href="https://www.clear.rice.edu/comp360/lectures/fall2008/TurtleFractalsL2New.pdf#page=5" target="_top">
                https://www.clear.rice.edu/comp360/lectures/fall2008/TurtleFractalsL2New.pdf#page=5</a>
*/
public class SierpinskiTurtle extends Turtle
{
   /**
      @param model   a reference to the {@link Model} that this {@link Turtle} is builing
      @param c       pen {@link Color} for this {@link Turtle}
      @param n       number of levels for the Sierpinski triangle
      @param length  side length
   */
   public SierpinskiTurtle(final Model model, final Color c,
                           final int n, final double length)
   {
      this(model, c, n, length, 0.0, 0.0, 0.0);
   }


   /**
      @param model   a reference to the {@link Model} that this {@link Turtle} is builing
      @param c       pen {@link Color} for this {@link Turtle}
      @param n       number of levels for the Sierpinski triangle
      @param length  side length
      @param xPos    the intial x-coordinate for this {@link Turtle}
      @param yPos    the intial y-coordinate for this {@link Turtle}
   */
   public SierpinskiTurtle(final Model model, final Color c,
                           final int n, final double length,
                           final double xPos, final double yPos)
   {
      this(model, c, n, length, xPos, yPos, 0.0);
   }


   /**
      @param model   a reference to the {@link Model} that this {@link Turtle} is builing
      @param c       pen {@link Color} for this {@link Turtle}
      @param n       number of levels for the Sierpinski triangle
      @param length  side length
      @param xPos    the intial x-coordinate for this {@link Turtle}
      @param yPos    the intial y-coordinate for this {@link Turtle}
      @param z       the z-plane for this {@link Turtle}
   */
   public SierpinskiTurtle(final Model model, final Color c,
                           final int n, final double length,
                           final double xPos, final double yPos, final double z)
   {
      super(model, xPos, yPos, z);
      setPenColor(c);
      sierpinski(n, length);
   }


   private void sierpinski(final int level, final double length)
   {
      if (0 == level)
      {
         // draw an equlateral triangle
         for (int i = 0; i < 3; ++i)
         {
            forward(length);
            turn(120);
         }
      }
      else
      {
         for (int i = 0; i < 3; ++i)
         {
            resize(0.5);
            sierpinski(level - 1, length);
            resize(2.0);
            move(length);
            turn(120);
         }
      }
   }


   /**
      For debugging.

      @return {@link String} representation of this {@code SierpinskiTurtle} object
   */
   @Override
   public String toString()
   {
      return "SierpinskiTurtle:\n" + super.toString();
   }
}//SierpinskiTurtle
