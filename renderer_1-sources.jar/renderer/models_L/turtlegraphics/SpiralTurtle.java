/*
 * Java 3D Renderer Project. The MIT License.
 * Copyright (c) 2022-2026, rlkraft@pnw.edu
 * See LICENSE for details.
*/

package renderer.models_L.turtlegraphics;

import renderer.scene.Model;

import java.awt.Color;

/**
   {@link Turtle} implementation of an unusual spiral curve.
   <p>
   See <a href="https://commons.wikimedia.org/wiki/File:Turtle_Graphics_Spiral.svg" target="_top">
                https://commons.wikimedia.org/wiki/File:Turtle_Graphics_Spiral.svg</a>
*/
public class SpiralTurtle extends Turtle
{
   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param c      pen {@link Color} for this {@link Turtle}
      @param n      number of spirals
   */
   public SpiralTurtle(final Model model, final Color c, final int n)
   {
      this(model, c, n, 0.0, 0.0, 0.0);
   }


   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param c      pen {@link Color} for this {@link Turtle}
      @param n      number of spirals
      @param xPos   the intial x-coordinate for this {@link Turtle}
      @param yPos   the intial y-coordinate for this {@link Turtle}
   */
   public SpiralTurtle(final Model model, final Color c, final int n,
                       final double xPos, final double yPos)
   {
      this(model, c, n, xPos, yPos, 0.0);
   }


   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param c      pen {@link Color} for this {@link Turtle}
      @param n      number of spirals
      @param xPos   the intial x-coordinate for this {@link Turtle}
      @param yPos   the intial y-coordinate for this {@link Turtle}
      @param z      the z-plane for this {@link Turtle}
   */
   public SpiralTurtle(final Model model, final Color c, final int n,
                       final double xPos, final double yPos, final double z)
   {
      super(model, xPos, yPos, z);
      setPenColor(c);
      spiral(n);
   }


   private void spiral(final int n)
   {
      for (int i = 0; i < n; ++i)
      {
         forward( 1.0 - ((double)i/(double)n) );
         turn(121);
      }
   }


   /**
      For debugging.

      @return {@link String} representation of this {@code SpiralTurtle} object
   */
   @Override
   public String toString()
   {
      return "SpiralTurtle:\n" + super.toString();
   }
}//SpiralTurtle
