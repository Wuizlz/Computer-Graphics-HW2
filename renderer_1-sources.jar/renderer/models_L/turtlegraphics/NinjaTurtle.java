/*
 * Java 3D Renderer Project. The MIT License.
 * Copyright (c) 2022-2026, rlkraft@pnw.edu
 * See LICENSE for details.
*/

package renderer.models_L.turtlegraphics;

import renderer.scene.Model;

import java.awt.Color;

/**
   {@link Turtle} implementation of an interesting drawing.
   <p>
   https://github.com/Michael0x2a/michael0x2a-website/blob/master/app/_posts/2014-02-15-turtle-examples.md#example-8-jumping-around-and-changing-speed
   <br>
   https://github.com/Michael0x2a/michael0x2a-website/blob/master/app/_assets/media/turtle-examples/twist.png
*/
public class NinjaTurtle extends Turtle
{
   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param c      pen {@link Color} for this {@link Turtle}
      @param n      number of radial lines
   */
   public NinjaTurtle(final Model model, final Color c, final int n)
   {
      this(model, c, n, 0.0, 0.0, 0.0);
   }


   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param c      pen {@link Color} for this {@link Turtle}
      @param n      number of radial lines
      @param xPos   the intial x-coordinate for this {@link Turtle}
      @param yPos   the intial y-coordinate for this {@link Turtle}
   */
   public NinjaTurtle(final Model model, final Color c, final int n,
                      final double xPos, final double yPos)
   {
      this(model, c, n, xPos, yPos, 0.0);
   }


   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param n      number of radial lines
      @param xPos   the intial x-coordinate for this {@link Turtle}
      @param yPos   the intial y-coordinate for this {@link Turtle}
      @param z      the z-plane for this {@link Turtle}
   */
   public NinjaTurtle(final Model model, final Color c, final int n,
                      final double xPos, final double yPos, final double z)
   {
      super(model, xPos, yPos, z);
      setPenColor(c);
      ninja(n);
   }


   private void ninja(final int n)
   {
      for (int i = 0; i < n; ++i)
      {
         forward(1.0);
         turn(30);
         forward(0.2);
         turn(-60);
         forward(0.5);
         turn(30);

         penUp();
         moveTo(xHome, yHome);
         penDown();

         turn(360 / n);
      }
   }


   /**
      For debugging.

      @return {@link String} representation of this {@code NinjaTurtle} object
   */
   @Override
   public String toString()
   {
      return "NinjaTurtle:\n" + super.toString();
   }
}//NinjaTurtle
