/*
 * Java 3D Renderer Project. The MIT License.
 * Copyright (c) 2022-2026, rlkraft@pnw.edu
 * See LICENSE for details.
*/

package renderer.models_L.turtlegraphics;

import renderer.scene.Model;

import java.awt.Color;

/**
   {@link Turtle} implementation of the Sierpinski curve.
   <p>
   See <a href="https://en.wikipedia.org/wiki/Sierpi%C5%84ski_triangle#Arrowhead_construction_of_Sierpi%C5%84ski_gasket" target="_top">
                https://en.wikipedia.org/wiki/Sierpi%C5%84ski_triangle#Arrowhead_construction_of_Sierpi%C5%84ski_gasket</a>
   <br>
   or <a href="https://en.wikipedia.org/wiki/Sierpi%C5%84ski_curve#Arrowhead_curve" target="_top">
               https://en.wikipedia.org/wiki/Sierpi%C5%84ski_curve#Arrowhead_curve</a>
   <br>
   or <a href="https://larryriddle.agnesscott.org/ifs/siertri/siertri.htm" target="_top">
               https://larryriddle.agnesscott.org/ifs/siertri/siertri.htm</a>
*/
public class SierpinskiCurveTurtle extends Turtle
{
   /**
      @param model   a reference to the {@link Model} that this {@link Turtle} is builing
      @param c       pen {@link Color} for this {@link Turtle}
      @param n       number of levels for the Sierpinski curve
      @param length  side length
   */
   public SierpinskiCurveTurtle(final Model model, final Color c,
                                final int n, final double length)
   {
      this(model, c, n, length, 0.0, 0.0, 0.0);
   }


   /**
      @param model   a reference to the {@link Model} that this {@link Turtle} is builing
      @param c       pen {@link Color} for this {@link Turtle}
      @param n       number of levels for the Sierpinski curve
      @param length  side length
      @param xPos    the intial x-coordinate for this {@link Turtle}
      @param yPos    the intial y-coordinate for this {@link Turtle}
   */
   public SierpinskiCurveTurtle(final Model model, final Color c,
                                final int n, final double length,
                                final double xPos, final double yPos)
   {
      this(model, c, n, length, xPos, yPos, 0.0);
   }


   /**
      @param model   a reference to the {@link Model} that this {@link Turtle} is builing
      @param c       pen {@link Color} for this {@link Turtle}
      @param n       number of levels for the Sierpinski curve
      @param length  side length
      @param xPos    the intial x-coordinate for this {@link Turtle}
      @param yPos    the intial y-coordinate for this {@link Turtle}
      @param z       the z-plane for this {@link Turtle}
   */
   public SierpinskiCurveTurtle(final Model model, final Color c,
                                final int n, final double length,
                                final double xPos, final double yPos, final double z)
   {
      super(model, xPos, yPos, z);
      setPenColor(c);
      curve(n, length, 60);
   }


   private void curve(final int n, final double length, final int angle)
   {
      if ( 0 == n )
      {
         forward(length);
      }
      else
      {
         turn(angle);
         curve(n - 1, length / 2.0, -angle);
         turn(-angle);
         curve(n - 1, length / 2.0,  angle);
         turn(-angle);
         curve(n - 1, length / 2.0, -angle);
         turn(angle);
      }
   }


   /**
      For debugging.

      @return {@link String} representation of this {@code SierpinskiCurveTurtle} object
   */
   @Override
   public String toString()
   {
      return "SierpinskiCurveTurtle:\n" + super.toString();
   }
}//SierpinskiCurveTurtle


/* Wikipedia version.
   public SierpinskiCurveTurtle(final Model model, final int n, final double length,
                                final double xPos, final double yPos, final double z)
   {
      super(model, xPos, yPos, z);
      if ( 0 == n % 2 )  // n is even
      {
         curve(n, length, 60);
      }
      else  // n is odd
      {
         turn(60);
         curve(n, length, -60);
      }
   }

   private void curve(final int n, final double length, final int angle)
   {
      if ( 0 == n )
      {
         forward(length);
      }
      else
      {
         curve(n - 1, length / 2.0, -angle);
         turn(angle);
         curve(n - 1, length / 2.0,  angle);
         turn(angle);
         curve(n - 1, length / 2.0, -angle);
      }
   }
*/
