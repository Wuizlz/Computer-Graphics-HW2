/*
 * Java 3D Renderer Project. The MIT License.
 * Copyright (c) 2022-2026, rlkraft@pnw.edu
 * See LICENSE for details.
*/

package renderer.models_L.turtlegraphics;

import renderer.scene.Model;

import java.awt.Color;

/**
   {@link Turtle} implementation of a pentagasket (Sierpinski 5-gon).
   <p>
   See <a href="https://en.wikipedia.org/wiki/N-flake#Pentaflake" target="_top">
                https://en.wikipedia.org/wiki/N-flake#Pentaflake</a>
   <br>
   or <a href="https://larryriddle.agnesscott.org/ifs/pentagon/pentagon.htm" target="_top">
               https://larryriddle.agnesscott.org/ifs/pentagon/pentagon.htm</a>
*/
public class PentagasketTurtle extends Turtle
{
   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param c      pen {@link Color} for this {@link Turtle}
      @param n      number of levels for the Pentagasket
   */
   public PentagasketTurtle(final Model model, final Color c, final int n)
   {
      this(model, c, n, 0.0, 0.0, 0.0);
   }


   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param c      pen {@link Color} for this {@link Turtle}
      @param n      number of levels for the Pentagasket
      @param xPos   the intial x-coordinate for this {@link Turtle}
      @param yPos   the intial y-coordinate for this {@link Turtle}
   */
   public PentagasketTurtle(final Model model, final Color c, final int n,
                            final double xPos, final double yPos)
   {
      this(model, c, n, xPos, yPos, 0.0);
   }


   /**
      @param model  a reference to the {@link Model} that this {@link Turtle} is builing
      @param c      pen {@link Color} for this {@link Turtle}
      @param n      number of levels for the Pentagasket
      @param xPos   the intial x-coordinate for this {@link Turtle}
      @param yPos   the intial y-coordinate for this {@link Turtle}
      @param z      the z-plane for this {@link Turtle}
   */
   public PentagasketTurtle(final Model model, final Color c, final int n,
                            double xPos, double yPos, final double z)
   {
      super(model, xPos, yPos, z);
      setPenColor(c);
      pentagasket(n);
   }


   private void pentagasket(final int level)
   {
      if (0 == level)
      {
         // draw a pentagon
         for (int i = 0; i < 5; ++i)
         {
            forward(1);
            turn(72);
         }
      }
      else
      {
         for (int i = 0; i < 5; ++i)
         {
            resize(0.5);
            pentagasket(level - 1);
            resize(2.0);
            move(1);
            turn(72);
         }
      }
   }


   /**
      For debugging.

      @return {@link String} representation of this {@code PentagasketTurtle} object
   */
   @Override
   public String toString()
   {
      return "PentagasketTurtle:\n" + super.toString();
   }
}//PentagasketTurtle
